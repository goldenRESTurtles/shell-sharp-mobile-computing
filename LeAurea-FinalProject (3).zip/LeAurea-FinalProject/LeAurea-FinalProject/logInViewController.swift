//
//  logInViewController.swift
//  LeAurea-FinalProject
//
//  Created by Aurea K Le on 12/7/24.
//

import UIKit
import FirebaseAuth

class logInViewController: UIViewController {
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var segCtrl: UISegmentedControl!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var confirmTextField: UITextField!
    @IBOutlet weak var confirmLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        logInSegCtrlAction(segCtrl!)
    }
    
    func createNewUser(){
        // create a new user
        guard passTextField.text == confirmTextField.text else {
            statusLabel.text = "Password confirmation failed."
            return
        } //check to see if password confirmed correctly
        Auth.auth().createUser(withEmail: emailTextField.text!, password: passTextField.text!) {
            (authResult, error) in
            if let error = error as NSError? {
                self.statusLabel.text = "\(error.localizedDescription)"
            }else {
                self.statusLabel.text = ""
                self.performSegue(withIdentifier: "loginSegue", sender: nil)
            }
        }
    }
    
    func logIn(){
        //login to application
        Auth.auth().signIn(withEmail: emailTextField.text!, password: passTextField.text!) {
            (authResult,error) in
            if let error = error as NSError? {
                self.statusLabel.text = "\(error.localizedDescription)"
            }else{
                self.statusLabel.text = ""
                self.performSegue(withIdentifier: "loginSegue", sender: nil)
            }
        }
    }
    
    @IBAction func logInSegCtrlAction(_ sender: Any) {
        switch segCtrl.selectedSegmentIndex{
        case 0: confirmTextField.isHidden = false
            confirmLabel.isHidden = false
            loginButton.setTitle("Sign Up", for: .normal)
        case 1: confirmTextField.isHidden = true
            confirmLabel.isHidden = true
            loginButton.setTitle("Log In", for: .normal)
        default:
            statusLabel.text = "not gonna happen"
        }
    }
    
    @IBAction func logButton(_ sender: Any) {
        if segCtrl.selectedSegmentIndex == 1{
            logIn()
        } else{
            createNewUser()
        }
    }
    
}
