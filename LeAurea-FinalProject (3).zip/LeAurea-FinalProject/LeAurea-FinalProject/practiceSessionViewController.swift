//
//  practiceSessionViewController.swift
//  LeAurea-FinalProject
//
//  Created by Aurea K Le on 12/7/24.
//

import UIKit

class practiceSessionViewController: UIViewController {
    @IBOutlet weak var timeDisplay: UILabel!
    
    var queue: DispatchQueue!
    var delegate: UIViewController! //set for the delegate method
    
    var minutes = 0
    var seconds = 0
    var minutesPracticed = 0
    var isTimerRunning = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateTimerDisplay()

    }
    
    func updateTimerDisplay(){
        timeDisplay.text = String(format: "%02d:%02d", minutes, seconds)
    }
    
    func popUpAlert(){
        let timesUpAlert = UIAlertController(title: "Times Up!", message: "Would you like to write a journal entry about your practice session?", preferredStyle: .alert)
        timesUpAlert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {_ in self.performSegue(withIdentifier: "timerToJournal", sender: nil) }))
        timesUpAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        self.present(timesUpAlert, animated: true, completion: nil)
    }
    
    func countDown(){
        if isTimerRunning { return } //prevent multiple timers from running
        isTimerRunning = true
        
        DispatchQueue.global(qos: .utility).async {
            while self.minutes > 0 || self.seconds > 0 {
                Thread.sleep(forTimeInterval: 1)
                
                if self.seconds == 0 && self.minutes > 0 {
                    self.minutes -= 1
                    self.minutesPracticed += 1
                    self.seconds = 59
                } else {
                    self.seconds -= 1
                }
                DispatchQueue.main.async {
                    self.updateTimerDisplay()
                }
            }
            DispatchQueue.main.async {
                self.addMoreCoins(minutes: self.minutesPracticed)
                self.popUpAlert()
            }
            self.isTimerRunning = false
        }
    }
    
    func addMoreCoins(minutes: Int) {
        let coinsEarnedFromPractice = minutes * 10
        let otherVC = delegate as! GetCoins
        otherVC.getCoins(coins: coinsEarnedFromPractice)
    }
    
    @IBAction func addTenMin(_ sender: Any) {
        self.minutes+=10
        updateTimerDisplay()
    }
    
    @IBAction func addOneMin(_ sender: Any) {
        self.minutes+=1
        updateTimerDisplay()
    }
    
    @IBAction func startTimer(_ sender: Any) {
        if !isTimerRunning {
            countDown()
        }
        }
    
}
