//
//  shopViewController.swift
//  LeAurea-FinalProject
//
//  Created by Aurea K Le on 12/8/24.
//

import UIKit

class itemCells: UITableViewCell{
    @IBOutlet weak var itemLabel: UILabel!
    @IBOutlet weak var benefitsLabel: UILabel!
    @IBOutlet weak var itemImage: UIImageView!
}

class shopViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    let itemsArray = ["Lettuce", "Banana", "Ball", "Yoyo", "Coffee", "Sleep Mask"]
    let priceArray = [50, 75, 100, 120, 75, 150]
    let benefitsArray = [10, 20, 15, 20, 10, 50]
    let benefitsStringArray = ["+10 hunger", "+20 hunger", "+15 happiness", "+20 happiness", "+10 energy","+50 energy"]
    let imageArray = ["lettuce-removebg-preview.png","banana-removebg-preview.png", "ball-removebg-preview.png", "yoyo-removebg-preview.png", "coffee-removebg-preview.png", "sleepMask-removebg-preview.png"]
    let textCell = "textCell"
    
    var delegate: UIViewController! //set for the delegate method
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Shop"
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsArray.count
    }
    
//displays items in cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: textCell, for: indexPath) as? itemCells else {
                return UITableViewCell()
            }
            
            cell.itemLabel.text = itemsArray[indexPath.row]
            cell.benefitsLabel.text = benefitsStringArray[indexPath.row]
            cell.itemImage.image = UIImage(named: imageArray[indexPath.row])
            return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let buyAlert = UIAlertController(title: "Purchase", message: "The \(itemsArray[indexPath.row]) costs \(priceArray[indexPath.row]) coins. Would you like to buy it?", preferredStyle: .alert)
        
        buyAlert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {_ in
            if self.itemsArray[indexPath.row] == "Lettuce" || self.itemsArray[indexPath.row] == "Banana" {
                
                let hungerDelegate = self.delegate as! GetHunger
                hungerDelegate.getHunger(hunger: self.benefitsArray[indexPath.row])
                
                let spendingDelegate = self.delegate as! GetDeductedCoins
                spendingDelegate.getDeductedCoins(deductions: self.priceArray[indexPath.row])
            }
            else if self.itemsArray[indexPath.row] == "Ball" || self.itemsArray[indexPath.row] == "Yoyo" {
                
                let happinessDelegate = self.delegate as! GetHappiness
                happinessDelegate.getHappiness(happy: self.benefitsArray[indexPath.row])
                
                let spendingDelegate = self.delegate as! GetDeductedCoins
                spendingDelegate.getDeductedCoins(deductions: self.priceArray[indexPath.row])
            }
            else if self.itemsArray[indexPath.row] == "Coffee" || self.itemsArray[indexPath.row] == "Sleep Mask" {
                
                let energyDelegate = self.delegate as! GetEnergy
                energyDelegate.getEnergy(energy: self.benefitsArray[indexPath.row])
                
                let spendingDelegate = self.delegate as! GetDeductedCoins
                spendingDelegate.getDeductedCoins(deductions: self.priceArray[indexPath.row])
            }
        }))
        
        buyAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        
        self.present(buyAlert, animated: true, completion: nil)
        tableView.deselectRow(at: indexPath, animated: true) //deselect row after touch
    }

}
