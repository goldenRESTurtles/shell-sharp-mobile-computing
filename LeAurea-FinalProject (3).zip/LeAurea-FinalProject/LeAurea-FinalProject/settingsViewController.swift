//
//  settingsViewController.swift
//  LeAurea-FinalProject
//
//  Created by Aurea K Le on 12/7/24.
//

import UIKit

class settingsViewController: UIViewController {
    var delegate: UIViewController!
    @IBOutlet weak var nightSwitch: UISwitch!
    @IBOutlet weak var catSwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if UserDefaults.standard.object(forKey: "nightSwitch") == nil {
            UserDefaults.standard.set(false, forKey: "nightSwitch") //starts as off
        }
        nightSwitch.isOn = UserDefaults.standard.bool(forKey: "nightSwitch")
        
        if UserDefaults.standard.object(forKey: "petSwitch") == nil {
            UserDefaults.standard.set(false, forKey: "petSwitch") //starts as off
        }
        catSwitch.isOn = UserDefaults.standard.bool(forKey: "petSwitch")
        
    }

    @IBAction func switchTimeOfDay(_ sender: UISwitch!) {
        let timeDelegate = delegate as! ChangeTheTime
        if sender.isOn {
            timeDelegate.changeToNight()
        } else {
            timeDelegate.changeToDay()
        }
        UserDefaults.standard.set(sender.isOn, forKey: "nightSwitch")
    }
    
    @IBAction func switchPets(_ sender: UISwitch!) {
        let petDelegate = delegate as! ChangePets
        if sender.isOn {
            petDelegate.changeTurtleToCat()
        } else {
            petDelegate.changeCatToTurtle()
        }
        UserDefaults.standard.set(sender.isOn, forKey: "petSwitch")
    }
    
}
