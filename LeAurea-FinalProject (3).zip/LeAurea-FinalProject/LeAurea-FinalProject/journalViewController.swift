//
//  journalViewController.swift
//  LeAurea-FinalProject
//
//  Created by Aurea K Le on 12/7/24.
//

import UIKit
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext

class Entry{
    var entryText:String?
    init(entryText: String? = nil) {
        self.entryText = entryText
    }
}

class journalViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var entryButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    let textCell = "textCell"
    var journalEntriesArray: [Entry] = []
    
    override func viewDidLoad() {
        entryButton.tintColor = UIColor(red: 0.64, green: 0.77, blue: 0.41, alpha: 1.0)
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        
        retrieveEntries() //retrieve previous journal entries using Core Data
        
    }
    
    @IBAction func pressAddEntry(_ sender: Any) {
        addEntryAlert()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return journalEntriesArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCell, for: indexPath)
        let singleEntry = journalEntriesArray[indexPath.row]
        cell.textLabel?.text = singleEntry.entryText  // cells will display the texts of journal entry
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let selectedEntry = journalEntriesArray[indexPath.row]
        
        let viewEntryAlert = UIAlertController(title: "View Entry", message: "", preferredStyle: .alert)
        
        viewEntryAlert.message = "Entry: \(selectedEntry.entryText ?? "no text")"
        
        viewEntryAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        
        tableView.deselectRow(at: indexPath, animated: true) //deselect row after touch
        
        self.present(viewEntryAlert, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            journalEntriesArray.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            deleteEntry(deleteIndex: indexPath.row)
        }
    } //delete a journal entry with a swipe
    
    func addEntryAlert(){
        let entryAlert = UIAlertController(title: "New Journal Entry", message: nil, preferredStyle: .alert)
        
        let textView = UITextView(frame: CGRect(x: 10, y: 50, width: 250, height: 150))//height change
        textView.font = UIFont.systemFont(ofSize: 16)
        textView.layer.borderWidth = 1
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.cornerRadius = 5
        
        entryAlert.view.addSubview(textView)
        
        entryAlert.addAction(UIAlertAction(title: "Save", style: .default, handler: {_ in self.addEntry(details: textView.text)})) //add textView content into journalEntriesArray
        entryAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        entryAlert.view.translatesAutoresizingMaskIntoConstraints = false
        let heightConstraints = NSLayoutConstraint(item: entryAlert.view!, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 300)
        entryAlert.view.addConstraint(heightConstraints)
        
        self.present(entryAlert, animated: true, completion: nil)
    }
    
    func addEntry(details: String?){
        if let userWriting = details{ //assign vars + check array for values
            let entry1 = Entry()
            entry1.entryText = userWriting
            
            storeEntry(journalWriting: userWriting)
            journalEntriesArray.append(entry1)
            
            tableView.reloadData()
        }
    }
    
    func storeEntry(journalWriting:String) {
        let entryObj = NSEntityDescription.insertNewObject(
            forEntityName: "JournalEntry",
            into: context)
        entryObj.setValue(journalWriting, forKey: "entryText")
        saveContext()
    }
    
    func retrieveEntries() {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "JournalEntry")
        do {
            let fetchedResults = try context.fetch(request) as? [NSManagedObject] ?? []
            journalEntriesArray = [] //clear other journal entries
            for result in fetchedResults {
                let someEntry = result.value(forKey: "entryText") as? String ?? "x"
                let journalEntry1 = Entry(entryText: someEntry)
                journalEntriesArray.append(journalEntry1)
            }
            tableView.reloadData()
        } catch {
            print("Error occurred while retrieving data")
            abort()
        }
    }
    
    func deleteEntry(deleteIndex:Int) {
     let request = NSFetchRequest<NSFetchRequestResult>(entityName: "JournalEntry")
     var fetchedResults: [NSManagedObject]

     do {
        try fetchedResults = context.fetch(request) as! [NSManagedObject]
                
        if fetchedResults.count > 0 {
           context.delete(fetchedResults[deleteIndex])
           appDelegate.saveContext()
        } //delete function for a journal entry
                
     } catch {
         print("Error occurred while clearing data")
         abort()
     }
    }
    
    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

}
