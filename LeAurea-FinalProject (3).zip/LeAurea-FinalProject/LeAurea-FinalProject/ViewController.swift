//
//  ViewController.swift
//  LeAurea-FinalProject
//
//  Created by Aurea K Le on 12/7/24.
//

import UIKit

protocol ChangeTheTime {
    func changeToDay()
    func changeToNight()
}

protocol ChangePets {
    func changeTurtleToCat()
    func changeCatToTurtle()
}

protocol GetCoins {
    func getCoins(coins: Int)
}

protocol GetHappiness {
    func getHappiness(happy: Int)
}

protocol GetHunger {
    func getHunger(hunger: Int)
}

protocol GetEnergy {
    func getEnergy(energy: Int)
}

protocol GetDeductedCoins {
    func getDeductedCoins(deductions: Int)
}

class ViewController: UIViewController, ChangeTheTime, ChangePets, GetCoins, GetHappiness, GetHunger, GetEnergy, GetDeductedCoins {
    @IBOutlet weak var bgImage: UIImageView!
    @IBOutlet weak var turtle: UIImageView!
    @IBOutlet weak var shopIcon: UIButton!
    @IBOutlet weak var settingsIcon: UIButton!
    @IBOutlet weak var practiceButton: UIButton!
    @IBOutlet weak var journalButton: UIButton!
    
    @IBOutlet weak var bubbleDisplay: UIImageView!
    @IBOutlet weak var happinessDisplay: UILabel!
    @IBOutlet weak var hungerDisplay: UILabel!
    @IBOutlet weak var energyDisplay: UILabel!
    @IBOutlet weak var coinDisplay: UILabel!
    
    var totalCoins: Int = 1000{ //can't go below 0 coins
        didSet{
            if totalCoins < 0 {
                totalCoins = 0
            }
        }
    }
    
    var happiness: Int = 50 { //can't go above 100 pts
        didSet{
            if happiness > 100 {
                happiness = 100
            }
        }
    }
    
    var energy: Int = 50 {
        didSet{
            if energy > 100 {
                energy = 100
            }
        }
    }

    var hunger: Int = 50 {
        didSet{
            if hunger > 100 {
                hunger = 100
            }
        }
    }
    
    var coinsEarned:Int?
    var happinessAdded:Int?
    var hungerAdded:Int?
    var energyAdded:Int?
    var coinsDeducted: Int?
    
    override func viewDidLoad() {
        practiceButton.tintColor = UIColor(red: 1.00, green: 0.87, blue: 0.20, alpha: 1.0)
        journalButton.tintColor = UIColor(red: 0.95, green: 0.56, blue: 0.09, alpha: 1.0)
        super.viewDidLoad()
        
        happinessDisplay.text = "Happiness: \(self.happiness)/100"
        hungerDisplay.text = "Hunger: \(self.hunger)/100"
        energyDisplay.text = "Energy: \(self.energy)/100"
        coinDisplay.text = "Coins: \(self.totalCoins)"
        
        let spot1 = CGPoint(x: 242.0, y: 561.0) //spots for pet to move to
        let spot2 = CGPoint(x: 185.0, y: 561.0)
        let spot3 = CGPoint(x: 128.0, y: 601.0)
        
        moveTurtle(spot1: spot1, spot2: spot2, spot3: spot3)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueToSettings",
           let nextVC = segue.destination as? settingsViewController{
            nextVC.delegate = self
        } else if segue.identifier == "segueToTimer",
                  let nextVC = segue.destination as? practiceSessionViewController{
            nextVC.delegate = self
        } else if segue.identifier == "segueToShop",
                  let nextVC = segue.destination as? shopViewController{
            nextVC.delegate = self
        }
    }
    
    func addCoins() { //earn coins from practice
        if let earnedCoins = self.coinsEarned {
            self.totalCoins += earnedCoins
            coinDisplay.text = "Coins: \(self.totalCoins)"
        }
    }
    
    func addHappiness() { //earn back points from buying from shop
        if let moreHappy = self.happinessAdded {
            self.happiness += moreHappy
            happinessDisplay.text = "Happiness: \(self.happiness)/100"
        }
    }
    
    func addHunger() {
        if let moreHunger = self.hungerAdded {
            self.hunger += moreHunger
            hungerDisplay.text = "Hunger: \(self.hunger)/100"
        }
    }
    
    func addEnergy() {
        if let moreEnergy = self.energyAdded {
            self.energy += moreEnergy
            energyDisplay.text = "Energy: \(self.energy)/100"
        }
    }
    
    func spendCoins() {
        if let coinsSpent = self.coinsDeducted {
            self.totalCoins -= coinsSpent
            coinDisplay.text = "Coins: \(self.totalCoins)"
        }
    }
    
    func getCoins(coins: Int){ //getter from practiceVC to mainVC
        self.coinsEarned = coins
        self.addCoins()
    }
    
    func getHappiness(happy: Int){ //getter from shop to mainVC
        self.happinessAdded = happy
        self.addHappiness()
    }
    
    func getHunger(hunger: Int){
        self.hungerAdded = hunger
        self.addHunger()
    }
    
    func getEnergy(energy: Int){
        self.energyAdded = energy
        self.addEnergy()
    }
    
    func getDeductedCoins(deductions: Int){
        self.coinsDeducted = deductions
        self.spendCoins()
    }
    
    func changeToNight(){
        bgImage.image = UIImage(named: "bg1-Night.png")
        
        let nightShopIcon = UIImage(named: "nightCoin-removebg-preview.png")
        shopIcon.setBackgroundImage(nightShopIcon, for: .normal)
        
        let nightSettingsIcon = UIImage(named: "settingsIconsNight-removebg-preview.png")
        settingsIcon.setBackgroundImage(nightSettingsIcon, for: .normal)
        
        practiceButton.tintColor = UIColor(red: 0.93, green: 0.64, blue: 0.95, alpha: 1.0)
        
        journalButton.tintColor = UIColor(red: 0.59, green: 0.35, blue: 0.71, alpha: 1.0)
        
        bubbleDisplay.image = UIImage(named: "nightBubble-removebg-preview.png")
    }
    
    func changeToDay(){
        bgImage.image = UIImage(named: "bg1.png")
        
        let dayShopIcon = UIImage(named: "dayCoin-removebg-preview.png")
        shopIcon.setBackgroundImage(dayShopIcon, for: .normal)
        
        let daySettingsIcon = UIImage(named: "settingIconDay-removebg-preview.png")
        settingsIcon.setBackgroundImage(daySettingsIcon, for: .normal)
        
        practiceButton.tintColor = UIColor(red: 1.00, green: 0.87, blue: 0.20, alpha: 1.0)
        
        journalButton.tintColor = UIColor(red: 0.95, green: 0.56, blue: 0.09, alpha: 1.0)
        
        bubbleDisplay.image = UIImage(named: "dayBubble-removebg-preview.png")
    }
    
    func changeTurtleToCat(){
        turtle.image = UIImage(named: "shellSharpCat-removebg-preview.png")
    }
    
    func changeCatToTurtle(){
        turtle.image = UIImage(named: "newTurtle-removebg-preview.png")
    }
    
    func moveTurtle(spot1: CGPoint, spot2: CGPoint, spot3: CGPoint){
        UIView.animate(withDuration: 2.0, delay: 0, animations: {
            self.turtle.center = spot2
        }) {_ in
            UIView.animate(withDuration: 2.0, delay: 0, animations: {
                self.turtle.center = spot3
            }) {_ in
                UIView.animate(withDuration: 2.0, delay: 0, animations: {
                    self.turtle.center = spot1
                }) {_ in
                    self.moveTurtle(spot1: spot1, spot2: spot2, spot3: spot3)
                }
            }
        }
    }
    
}

